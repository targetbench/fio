build_fio()
{
    set -e
    ARCH=`uname -i`

    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]
        then
            make clean
            ./configure
            make -j16
    elif [ $ARCH = "arm_64" -o $ARCH = "arm_32" ]
        then
            ./configure --cpu=arm
            make
    else
        ./configure
        make
    fi
}

build_fio

